from google.adk.agents import BaseAgent
from google.adk.events import Event
from google.genai import types

class DecisionAgent(BaseAgent):
    async def run_async(self, context, **kwargs):
        # Get analysis summary from parent agent's state
        summary = {}
        for agent_name, agent_state in context.agent_states.items():
            if "analysis_summary" in agent_state:
                summary = agent_state["analysis_summary"]
                break
        
        alert_needed = (
            summary.get("error_count", 0) > 0 
            or summary.get("severity") in ["high", "critical"]
        )

        # Store decision in agent state
        agent_id = self.name
        if agent_id not in context.agent_states:
            context.agent_states[agent_id] = {}
        context.agent_states[agent_id]["alert_needed"] = alert_needed
        
        print("\n[Decision] Alert needed:", alert_needed)

        # Yield an Event object with the decision
        content = types.Content(
            role="model",
            parts=[types.Part(text=f"Alert needed: {alert_needed}")]
        )
        event = Event(author=self.name, content=content)
        yield event
