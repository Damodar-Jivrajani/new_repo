from google.adk.agents import BaseAgent
from google.adk.events import Event
from google.genai import types
import json

class ReporterAgent(BaseAgent):
    async def run_async(self, context, **kwargs):
        # Get analysis and alert status from parent agents' states
        summary = {}
        alert = False
        
        for agent_name, agent_state in context.agent_states.items():
            if "analysis_summary" in agent_state:
                summary = agent_state["analysis_summary"]
            if "alert_needed" in agent_state:
                alert = agent_state["alert_needed"]

        print("\n========== SRE REPORT ==========")

        if alert:
            print("🚨 ALERT! Issues detected in logs!")
        else:
            print("✅ System healthy. No critical issues found.")

        print("Summary:", summary)
        print("================================")

        # Yield an Event object with the report
        report_text = f"""SRE REPORT
        Alert: {alert}
        Summary: {json.dumps(summary, indent=2)}
        """
        content = types.Content(
            role="model",
            parts=[types.Part(text=report_text)]
        )
        event = Event(author=self.name, content=content)
        yield event
