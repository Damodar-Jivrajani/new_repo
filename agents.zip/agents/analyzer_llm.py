# import yaml
# from google.adk.agents import LlmAgent
# from google_genai import Client
# from dotenv import load_dotenv
# import os

# # Load API key
# load_dotenv()

# client = Client(api_key=os.getenv("GEMINI_API_KEY"))

# config = yaml.safe_load(open("config/settings.yaml"))

# # LLM Agent using Gemini through google-genai client wrapper
# analyzer = LlmAgent(
#     name="Gemini_LogAnalyzer",
#     instruction="""
#     You are an expert SRE log analyst.
#     Analyze the given logs and produce a JSON dictionary with keys:
#     - errors
#     - warnings
#     - error_count
#     - warning_count
#     - severity (low/medium/high)
    
#     Logs:
#     {raw_logs}
#     """,
#     model=config["llm"]["model"],
#     client=client,               # 👈 Gemini client injected here
#     output_key="analysis_summary"
# )






from google.adk.agents import LlmAgent, BaseAgent
from google.adk.events import Event
from google import genai
from google.genai import types
import json
from dotenv import load_dotenv
import os

# Load API key
load_dotenv()

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

class AnalyzerAgent(BaseAgent):
    name: str = "llm_analyzer"

    async def run_async(self, context, **kwargs):
        # Get logs from parent agent's state
        raw_logs = ""
        for agent_name, agent_state in context.agent_states.items():
            if "raw_logs" in agent_state:
                raw_logs = agent_state["raw_logs"]
                break
        
        if not raw_logs:
            raw_logs = ""
            
        prompt = f"""
        You are an SRE LLM agent. Analyze the following logs and return JSON:
        {{
            "severity": "",
            "root_cause": "",
            "summary": "",
            "recommended_action": ""
        }}

        Logs:
        {raw_logs}
        """

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt
        )

        text = response.text

        try:
            # Extract JSON from markdown code blocks if present
            if "```json" in text:
                start = text.find("```json") + len("```json")
                end = text.find("```", start)
                text = text[start:end].strip()
            elif "```" in text:
                start = text.find("```") + len("```")
                end = text.find("```", start)
                text = text[start:end].strip()
            
            analysis = json.loads(text)
            # Store analysis in agent state
            agent_id = self.name
            if agent_id not in context.agent_states:
                context.agent_states[agent_id] = {}
            context.agent_states[agent_id]["analysis_summary"] = analysis
            print("[Analyzer] Analysis complete:")
            print(analysis)
            
            # Yield an Event object with the analysis
            content = types.Content(
                role="model",
                parts=[types.Part(text=json.dumps(analysis, indent=2))]
            )
            event = Event(author=self.name, content=content)
            yield event
        except Exception as e:
            print(f"[Analyzer] Error: {e}")
            content = types.Content(
                role="model",
                parts=[types.Part(text=f"Error: LLM returned non-JSON. Raw: {text}")]
            )
            event = Event(author=self.name, content=content)
            yield event