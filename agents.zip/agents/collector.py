from google.adk.agents import BaseAgent
from google.adk.events import Event
from google.genai import types
from pathlib import Path

class LogCollectorAgent(BaseAgent):
    async def run_async(self, context, **kwargs):
        log_file = Path("data/dummy_logs.txt")
        logs = log_file.read_text().strip().split("\n")

        # Store logs in agent state
        agent_id = self.name
        if agent_id not in context.agent_states:
            context.agent_states[agent_id] = {}
        context.agent_states[agent_id]["raw_logs"] = "\n".join(logs)
        
        print("[Collector] Collected logs:")
        for log in logs:
            print(" ", log)

        # Yield an Event object with the logs as content
        content = types.Content(
            role="user",
            parts=[types.Part(text=f"Collected {len(logs)} log entries")]
        )
        event = Event(author=self.name, content=content)
        yield event
