from google.adk.agents import SequentialAgent
from agents.collector import LogCollectorAgent
from agents.analyzer_llm import AnalyzerAgent
from agents.decision import DecisionAgent
from agents.reporter import ReporterAgent

sre_pipeline = SequentialAgent(
    name="SRE_Multi_Agent_Pipeline_Gemini",
    sub_agents=[
        LogCollectorAgent(name="Collector"),
        AnalyzerAgent(name="Analyzer"),
        DecisionAgent(name="DecisionMaker"),
        ReporterAgent(name="Reporter")
    ]
)
